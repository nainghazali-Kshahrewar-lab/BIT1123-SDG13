# Climate Action Manager

Java Swing group project aligned with **UN SDG 13: Climate Action**.

## Features
- User registration
- Transport, energy and waste activity tracking
- Estimated CO2 emission calculations
- Green action records
- Recommendations
- Activity/report summaries
- ArrayList collections
- HashMap-based emission factors
- TXT file persistence
- Input validation
- Java Swing GUI

## OOP Demonstration
- **Encapsulation:** private fields with getters/setters
- **Inheritance:** TransportActivity, EnergyActivity and WasteActivity extend Activity
- **Abstraction:** Activity is an abstract class
- **Polymorphism:** `ArrayList<Activity>` stores different Activity subclasses and calls overridden `calculateEmission()` at runtime

## Project Structure
```text
Climate-Action/
├── climate-action-manager/
│   └── src/climateaction/
│       ├── Main.java
│       ├── DataStore.java
│       ├── User.java
│       ├── Activity.java
│       ├── TransportActivity.java
│       ├── EnergyActivity.java
│       ├── WasteActivity.java
│       ├── GreenAction.java
│       ├── CarbonCalculator.java
│       ├── RecommendationService.java
│       ├── ReportService.java
│       └── FileManager.java
├── data/
│   ├── users.txt
│   ├── activities.txt
│   └── green_actions.txt
└── docs/
```

## Compile
From the project root:

```bash
cd climate-action-manager
mkdir -p out
javac -d out src/climateaction/*.java
```

## Run
```bash
java -cp out climateaction.Main
```

The application creates/uses the `data` folder for persistent TXT storage.

## Note on emission factors
The emission factors in `CarbonCalculator` are **illustrative values for an academic software simulation**, not direct real-world measurement values. They should be documented as such in the report.
